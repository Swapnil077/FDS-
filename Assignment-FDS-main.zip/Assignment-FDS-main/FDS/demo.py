cricket=[]
badmitan=[]
football=[]
A=int(input("enter a number of student who play cricket"))
for n in range (0,A):
  a=str(input("enter a students"))
  cricket.append(a)
print(cricket)
B=int(input("number of studentswho play badmintan"))
for n in range(0,B):
  b=str(input("enter name of students"))
  badmitan.append(b)
print(badmitan)
C=int(input("number of students who plays football"))
for n in range(0,c):
  c=str(input("name of students"))
  football.append(c)
print(football)
def first(cricket,badmintan):   
  newlist=[]
  len1=len(cricket)
  len2=len(badmintan)
  for i in range (len1):
   for j in range (len2):
     if(cricket[i]==badmintan[j]):
       newlist.append(cricket[i])
       print("list of students who play both cricket and badmintan",newlist)
       print(cricket,badmintan)

def second (cricket,badmintan):
  newlist=[]
  len1=(cricket)
  len2=(badmintan)
  flag=0
  for i in range(len1):
    for j in range(len2):
      if(cricket[i]==badmintan[j]):
        flag=1
        break
      if(flag==0):
        newlist.append(cricket[i])
        flag=0
        for i in range (len1):
          for j in range (len2):
            if (badmintan[i]==cricket[j]):
              flag=1
              break
            if(flag==0):
              newlist.append(badmintan[i])
              flag=0
              print("students who play either cricket and badimintan",newlist)
              second(cricket,badmintan)


